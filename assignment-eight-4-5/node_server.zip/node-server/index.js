const express = require('express');
const app = express();
const path = require('path');
const port = 8000;

const public = path.join(__dirname, 'public');

app.use('/static', express.static(public));

app.get('/', (req, res) => {
    res.sendFile(path.join(public, 'index.html'));
});

app.get('/eight-1', (req, res) => {
    res.sendFile(path.join(public, 'assignment-eight-1', 'index.html'));
});

app.get('/eight-2', (req, res) => {
    res.sendFile(path.join(public, 'assignment-eight-2', 'main.scss'));
});

app.get('/eight-3', (req, res) => {
    res.sendFile(path.join(public, 'assignment-eight-3', 'index.html'));
});

app.listen(port, () => { console.log('Serving files...') });