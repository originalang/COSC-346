function Assignment(props) {
    return <div class="column margin"><div class="ui card">
        <div class="content">
            <div class="header">{props.header}</div>
        </div>
        <div class="content">
            <h4 class="ui sub header">{props.subheader}</h4>
            <div class="ui small feed">
                <div class="event">
                    <div class="content">
                        <div class="summary">
                            {props.details}
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="extra content">
            <a class="ui green basic button" href={props.href} target="_blank">Go to project</a>
        </div>
    </div>
    </div>;
}

appendDOM('div', <Assignment header="React" subheader="Assignemnt Eight-1" details="Simple react functional components" href="http://127.0.0.1:8000/eight-1"/>, document.getElementById('root'));
appendDOM('div', <Assignment header="SASS" subheader="Assignemnt Eight-2" details="Converting CSS to SCSS" href="http://127.0.0.1:8000/eight-2"/>, document.getElementById('root'));
appendDOM('div', <Assignment header="SVG" subheader="Assignemnt Eight-3" details="Simple shapes created with SVG" href="http://127.0.0.1:8000/eight-3"/>, document.getElementById('root'));

function appendDOM(nodeType, element, root) {
    const newNode = document.createElement(nodeType);

    root.appendChild(newNode);
    ReactDOM.render(element, newNode);
}